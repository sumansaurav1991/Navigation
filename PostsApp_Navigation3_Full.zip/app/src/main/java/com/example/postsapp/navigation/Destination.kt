
package com.example.postsapp.navigation
import kotlinx.serialization.Serializable

@Serializable data object Home
@Serializable data class Posts(val name:String)
