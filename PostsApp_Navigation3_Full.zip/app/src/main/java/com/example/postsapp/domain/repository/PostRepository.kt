
package com.example.postsapp.domain.repository
import kotlinx.coroutines.flow.Flow
import com.example.postsapp.domain.model.Post

interface PostRepository{
    fun getPosts(): Flow<List<Post>>
}
